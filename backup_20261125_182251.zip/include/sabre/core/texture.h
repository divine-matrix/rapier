#pragma once

#include "sabre/core/core.h"
#include <GL/glew.h>
#include <SDL3/SDL.h>
#include <cstdint>
#include <vector>

namespace sabre::core {

struct TextureBuffer {
  std::vector<uint32_t> buffer;
};

struct TextureRectSystem {
  // NOTE: Basic metadata for texture
  std::vector<float> destx;
  std::vector<float> desty;
  std::vector<float> destwidth;
  std::vector<float> destheight;
  std::vector<uint32_t> width;
  std::vector<uint32_t> height;
  std::vector<sabre_TextureFilterMode> filterMode;
  std::vector<bool> isDirty;
  // NOTE: Texture buffer stuff
  std::vector<TextureBuffer> buffers;
  // Currently unused
  // std::vector<uint32_t> bufferIndex;
  std::vector<GLuint> glTextureId;
};

struct sabre_RenderRect {
  float x = 0.0f;
  float y = 0.0f;
  float width = 0.0f;
  float height = 0.0f;
};

struct TextureRect {
  uint32_t width = 0;
  uint32_t height = 0;
  sabre_TextureFilterMode filterMode = sabre_TextureFilterMode::NEAREST;
  std::vector<uint32_t> textureBuffer;
  sabre_RenderRect renderRect{};
  GLuint glTextureId = 0;
  bool isDirty = true;
};

TextureRect sabre_CreateProcTextureObject(sabre_GlobalContext &gctx,
                                                      uint32_t width,
                                                      uint32_t height);

TextureRect
sabre_CreateProcTextureObject(sabre_GlobalContext &gctx, uint32_t width,
                              uint32_t height,
                              sabre_TextureFilterMode filterMode);

TextureRect getData(uint32_t idx);
void updateTextureBuffer();

void uploadTextureBuffer(TextureRect &procTex);

// FIX: Passed sabre_GlobalContext so shaders can be loaded via sabre_LoadFile
void sabre_RenderProcTextureObject(const sabre_GlobalContext &gctx,
                                   SDL_Window *window,
                                   TextureRect &procTex);

void shutdownProcTextureRenderer();

void destroyProcTextureObject(TextureRect &procTex);

} // namespace sabre::core
